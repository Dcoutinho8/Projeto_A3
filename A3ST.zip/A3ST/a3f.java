
package a3st;
import javax.swing.SwingUtilities;
import java.awt.Dimension;


public class a3f extends javax.swing.JFrame {

    public a3f() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Paciente = new javax.swing.JButton();
        Instituição = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1281, 766));
        setSize(new java.awt.Dimension(1280, 720));
        getContentPane().setLayout(null);

        Paciente.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        Paciente.setText("Paciente");
        Paciente.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Paciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PacienteActionPerformed(evt);
            }
        });
        getContentPane().add(Paciente);
        Paciente.setBounds(220, 390, 150, 40);

        Instituição.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        Instituição.setText("Instituição");
        Instituição.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Instituição.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InstituiçãoActionPerformed(evt);
            }
        });
        getContentPane().add(Instituição);
        Instituição.setBounds(220, 470, 150, 40);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\tiago\\Downloads\\WhatsApp Image 2022-11-08 at 21.54.14.jpeg")); // NOI18N
        jPanel1.add(jLabel1);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 1280, 720);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PacienteActionPerformed
      A31 frame = new A31();
         frame.setVisible(true);
    }//GEN-LAST:event_PacienteActionPerformed

    private void InstituiçãoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InstituiçãoActionPerformed
       A3instituição inst = new A3instituição();
       inst.setVisible(true);
    }//GEN-LAST:event_InstituiçãoActionPerformed

    public void getFrame()
    {
        setVisible(true);
        //setBounds(400,100,500,500);
        setSize(1278,720);
        //setLocation(52,300);
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(a3f.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(a3f.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(a3f.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(a3f.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new a3f().setVisible(true);

            }
        });    
        
     
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Instituição;
    private javax.swing.JButton Paciente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
